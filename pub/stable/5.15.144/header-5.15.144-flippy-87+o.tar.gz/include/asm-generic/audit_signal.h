__NR_kill,
__NR_tgkill,
__NR_tkill,
