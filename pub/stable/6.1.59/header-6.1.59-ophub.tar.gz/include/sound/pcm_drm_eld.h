/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __SOUND_PCM_DRM_ELD_H
#define __SOUND_PCM_DRM_ELD_H

int snd_pcm_hw_constraint_eld(struct snd_pcm_runtime *runtime, void *eld);

#endif
